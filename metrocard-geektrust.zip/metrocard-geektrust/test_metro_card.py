import unittest
from metro_card import MetroCard

class TestMetroCard(unittest.TestCase):

    def test_single_journey_no_discount(self):
        metro = MetroCard()
        metro.balance('MC1', 100)
        metro.check_in('MC1', 'ADULT', 'CENTRAL')
        self.assertEqual(metro.cards['MC1'], 80)

    def test_return_journey_discount_applied(self):
        metro = MetroCard()
        metro.balance('MC1', 100)
        metro.check_in('MC1', 'ADULT', 'CENTRAL')
        metro.check_in('MC1', 'ADULT', 'CENTRAL')
        self.assertAlmostEqual(metro.cards['MC1'], 90)

    def test_insufficient_balance_with_service_charge(self):
        metro = MetroCard()
        metro.balance('MC1', 10)
        metro.check_in('MC1', 'ADULT', 'AIRPORT')
        self.assertGreaterEqual(metro.cards['MC1'], 0)
        self.assertIn('AIRPORT', metro.total_collections)

    def test_summary_output(self):
        metro = MetroCard()
        metro.balance('MC1', 100)
        metro.check_in('MC1', 'ADULT', 'CENTRAL')
        summary = metro.get_summary()
        self.assertIn("TOTAL_COLLECTION CENTRAL 20 0", summary)
        self.assertIn("ADULT 1", summary)

if __name__ == '__main__':
    unittest.main()
