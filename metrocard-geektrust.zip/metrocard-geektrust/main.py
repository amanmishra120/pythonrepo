import sys
from metro_card import MetroCard

def process_input(filename):
    metro = MetroCard()
    with open(filename) as f:
        for line in f:
            parts = line.strip().split()
            if not parts:
                continue
            if parts[0] == "BALANCE":
                metro.balance(parts[1], float(parts[2]))
            elif parts[0] == "CHECK_IN":
                metro.check_in(parts[1], parts[2], parts[3])
    for line in metro.get_summary():
        print(line)

if __name__ == "__main__":
    process_input(sys.argv[1])
