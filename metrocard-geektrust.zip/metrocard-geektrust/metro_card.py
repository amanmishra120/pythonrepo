from collections import defaultdict
import math

FARES = {'CENTRAL': 20, 'AIRPORT': 50}
DISCOUNT = 0.5
SERVICE_CHARGE = 0.02

class MetroCard:
    def __init__(self):
        self.cards = defaultdict(float)
        self.journey_counts = defaultdict(lambda: defaultdict(int))
        self.total_collections = defaultdict(float)
        self.total_discounts = defaultdict(float)
        self.passenger_counts = defaultdict(lambda: defaultdict(int))

    def balance(self, card_number, amount):
        self.cards[card_number] += float(amount)

    def check_in(self, card_number, passenger_type, station):
        fare = FARES[station]
        count = self.journey_counts[card_number][station]
        is_return = count % 2 == 1
        applied_fare = fare * DISCOUNT if is_return else fare

        if self.cards[card_number] < applied_fare:
            needed = applied_fare - self.cards[card_number]
            service_charge = math.ceil(needed * SERVICE_CHARGE)
            total_added = needed + service_charge
            self.cards[card_number] += total_added
            self.total_collections[station] += service_charge
        else:
            self.total_collections[station] += applied_fare

        if is_return:
            self.total_discounts[station] += fare * DISCOUNT

        self.cards[card_number] -= applied_fare
        self.journey_counts[card_number][station] += 1
        self.passenger_counts[station][passenger_type] += 1

    def get_summary(self):
        summaries = []
        for station in sorted(self.total_collections.keys()):
            summaries.append(f"TOTAL_COLLECTION {station} {int(self.total_collections[station])} {int(self.total_discounts[station])}")
            summaries.append("PASSENGER_TYPE_SUMMARY")
            sorted_passengers = sorted(
                self.passenger_counts[station].items(),
                key=lambda x: (-x[1], x[0])
            )
            for passenger_type, count in sorted_passengers:
                summaries.append(f"{passenger_type} {count}")
        return summaries
